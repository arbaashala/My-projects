import java.util.HashMap;
import java.util.Map;
public class ATM {
    private Map<String, User> users;
    public ATM() {
        users = new HashMap<>();
        // Sample users
        users.put("12345", new User("John Doe", "12345", 1000.00));
        users.put("67890", new User("Jane Smith", "67890", 500.00));
    }
    public User getUser(String personalNumber) {
        return users.get(personalNumber);
    }
    public void start() {
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.print("Enter your personal number: ");
        String personalNumber = scanner.nextLine();
        User user = getUser(personalNumber);
        if (user == null) {
            System.out.println("User not found.");
            return;
        }
        System.out.println("Welcome " + user.getName());
        System.out.println("Your current balance is: $" + user.getBalance());
        System.out.print("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();
        user.withdraw(amount);
        scanner.close();
    }
}
