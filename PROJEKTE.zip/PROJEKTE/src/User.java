public class User {
    private String name;
    private String personalNumber;
    private double balance;
    public User(String name, String personalNumber, double balance) {
        this.name = name;
        this.personalNumber = personalNumber;
        this.balance = balance;
    }
    public String getName() {
        return name;
    }
    public String getPersonalNumber() {
        return personalNumber;
    }
    public double getBalance() {
        return balance;
    }
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful. Your new balance is: $" + balance);
        } else {
            System.out.println("Insufficient funds. Your balance is: $" + balance);
        }
    }
}
