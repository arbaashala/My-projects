package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.Date;

public class User extends Person {
    private int userId;
    private String email;
    private String password;
    private Date dateOfBirth;
    private String profileImage;

    public User(String name, String surname, int age, String city, String gender, String nationality, int userId, String email, String password, Date dateOfBirth, String profileImage) throws UserException {
        super(name, surname, age, city, gender, nationality);
        setUserId(userId);
        setEmail(email);
       setPassword(password);
        setDateOfBirth(dateOfBirth);
        setProfileImage(profileImage);
    }


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        if (userId < 0 || userId > 100) {
            throw new IndexOutOfBoundsException("User id out of bounds");
        }
        this.userId = userId;
    }



    public String getEmail() {
        return email;
    }

    public void setEmail(String email) throws UserException {
        if (email == null || email.trim().isEmpty()) {
            throw  new UserException("Email cannot be empty");
        }
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) throws UserException {
        if (password == null || password.trim().isEmpty()) {
            throw  new UserException("Password cannot be empty");
        }
        this.password = password;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) throws UserException {
       if (dateOfBirth == null || dateOfBirth.after(new Date())) {
           throw  new UserException("Date of birth cannot be empty");
       }
        this.dateOfBirth = dateOfBirth;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        if (profileImage == null || profileImage.trim().isEmpty()) {
            throw  new IllegalArgumentException("Profile image cannot be empty");
        }
        this.profileImage = profileImage;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
