package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.Date;

public class Album {
    private int albumId;
    private int artistId;
    private String name;
    private Date releaseDate;
    private String image;

    public Album(int albumId, int artistId, String name, Date releaseDate, String image) {
        this.albumId = albumId;
        this.artistId = artistId;
        this.name = name;
        this.releaseDate = releaseDate;
        this.image = image;
    }

    public int getAlbumId() {
        return albumId;
    }

    public void setAlbumId(int albumId) {
        if (albumId < 0 ) {
            throw new IllegalArgumentException("Numri nuk mundet te jete negativ!");
        }
        this.albumId = albumId;
    }

    public int getArtistId() {
        return artistId;
    }

    public void setArtistId(int artistId) {
       if (artistId < 0) {
           throw new IllegalArgumentException("ID e artistit nuk mundet te jete negativ!");
       }
        this.artistId = artistId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Emri eshte i zbrazet");
        }
        this.name = name;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        if (releaseDate == null || releaseDate.after(new Date())) {
            throw new IllegalArgumentException("Data e lansimit eshte dhene gabim!");
        }
        this.releaseDate = releaseDate;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
       if (image == null || image.isEmpty()) {
           throw new IllegalArgumentException("Nuk ka imazh!");
       }
        this.image = image;
    }

    @Override
    public String toString() {
        return "Album{" +
                "albumId=" + albumId +
                ", artistId=" + artistId +
                ", name='" + name + '\'' +
                ", releaseDate=" + releaseDate +
                ", image='" + image + '\'' +
                '}';
    }
}

