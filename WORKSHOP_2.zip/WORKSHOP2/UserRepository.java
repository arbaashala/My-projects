package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.List;

public interface UserRepository extends Repository<User> {

}
