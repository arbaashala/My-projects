package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.List;

import java.util.ArrayList;


public class AlbumsRepositoryImpl implements AlbumsRepository {
    private List<Album> albums;

    public AlbumsRepositoryImpl() {
        this.albums = new ArrayList<>();
    }

    @Override
    public void add(Album album) {

        albums.add(album);
    }

    @Override
    public Album get(int id) {
      return albums.get(id);
    }

    @Override
    public void remove(int id) {
        albums.removeIf(album -> album.getAlbumId() == id);
    }

    @Override
    public List<Album> findAll() {
        return new ArrayList<>(albums);
    }
}
