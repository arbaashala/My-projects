package oop.intro_to_classes_and_objects.WORKSHOP2;

public class Track {
    private int trackId;
    private int albumId;
    private String name;
    private int duration; // duration in seconds
    private String path;

    public Track(int trackId, int albumId, String name, int duration, String path) {
        this.trackId = trackId;
        this.albumId = albumId;
        this.name = name;
        this.duration = duration;
        this.path = path;
    }

    public int getTrackId() {
        return trackId;
    }

    public void setTrackId(int trackId) {
       if (trackId < 0) {
           throw new IllegalArgumentException("ID e track nuk mund te jete negative");
       }
        this.trackId = trackId;
    }

    public int getAlbumId() {
        return albumId;
    }

    public void setAlbumId(int albumId) {
        if (albumId < 0) {
            throw new IllegalArgumentException("ID e album nuk mund te jete negative!");
        }
        this.albumId = albumId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Emri nuk mund te jete null, ose i zbrazet!");
        }
        this.name = name;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        if (duration <= 0) {
            throw new IllegalArgumentException("Kohezgjatja e kenges nuk mund te jete numer negativ!");
        }
        this.duration = duration;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        if (path == null || path.trim().isEmpty()) {
            throw new IllegalArgumentException("Path-i nuk mund te jete me hapsira, ose e zbrazet!");
        }
        this.path = path;
    }

    @Override
    public String toString() {
        return "Track{" +
                "trackId=" + trackId +
                ", albumId=" + albumId +
                ", name='" + name + '\'' +
                ", duration=" + duration +
                ", path='" + path + '\'' +
                '}';
    }
}

