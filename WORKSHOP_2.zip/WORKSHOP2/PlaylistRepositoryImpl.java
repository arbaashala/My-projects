package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.ArrayList;
import java.util.List;


public class PlaylistRepositoryImpl implements PlaylistRepository {
    private List<Playlist> playlists = new ArrayList<>();

    @Override
    public void add(Playlist playlist) {
        playlists.add(playlist);
    }

    @Override
    public Playlist get(int playlistId) {
        return playlists.get(playlistId);
    }

    @Override
    public void remove(int playlistId) {
        playlists.remove(playlistId);
    }

    @Override
    public List<Playlist> findAll() {
        return new ArrayList<>(playlists);
    }
}
