package oop.intro_to_classes_and_objects.WORKSHOP2;

public class Artist extends Person {
    private int artistId;
    private String Stagename;
    private String genre;
    private String image;

    public Artist(String name, String surname, int age, String city, String gender, String nationality, int artistId, String stagename, String genre, String image) {
        super(name, surname, age, city, gender, nationality);
       setArtistId(artistId);
        setStagename(stagename);
        setGenre(genre);
        setImage(image);
    }

    public int getArtistId() {
        return artistId;
    }

    public void setArtistId(int artistId)  {
       if (artistId <= 0 ) {
           throw new IllegalArgumentException("Id e artistit nuk mund te jete negativ!");
       }
        this.artistId = artistId;
    }

    public String getStagename() {
        return Stagename;
    }

    public void setStagename(String stagename) {
        if (stagename == null || stagename.trim().isEmpty()) {
            throw new IllegalArgumentException("Emri i artistit nuk mund te jete i zbrazet!");
        }
        this.Stagename = stagename;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
       if (genre == null || genre.trim().isEmpty()) {
           throw new IllegalArgumentException("Zhandri nuk mund te jete i zbrazet!");
       }
        this.genre = genre;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        if (image == null || image.isEmpty()) {
            throw new IllegalArgumentException("Foto nuk mund te jete e zbrazet!");
        }
        this.image = image;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}

