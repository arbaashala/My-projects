package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.List;

public interface Repository<T> {
    public void add(T t);
    public T get(int id);
    public void remove(int id);
    List<T> findAll();
}
