package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.ArrayList;
import java.util.List;

public class UserRepositoryImpl implements UserRepository {
    private List<User> users = new ArrayList<>();

    @Override
    public void add(User user) {
        users.add(user);
    }

    @Override
    public User get(int userId) {
        return users.get(userId);
    }

    @Override
    public void remove(int userId) {
        users.remove(userId);
    }

    @Override
    public List<User> findAll() {
        return new ArrayList<>(users);
    }
}

