package oop.intro_to_classes_and_objects.WORKSHOP2;

public interface TracksRepository extends Repository<Track>{


}
