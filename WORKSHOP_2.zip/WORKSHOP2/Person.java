package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.time.LocalDate;

public class Person {
    private String name;
    private String surname;
    private int age;
    private String city;
    private String gender;
    private String nationality;



    public Person() {
    }

    public Person(String name, String surname, int age, String city, String gender, String nationality) {
        setName(name);
        setSurname(surname);
        setAge(age);
        setCity(city);
        setGender(gender);
        setNationality(nationality);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Emri nuk mund te jete zbrazet ");
        }
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        if (surname == null || surname.trim().isEmpty()) {
            throw new IllegalArgumentException("Mbiemri nuk mund te jete zbrazet ");
        }
        this.surname = surname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age < 0 || age > 120) {
            throw new IllegalArgumentException("Mosha nuk mund te jete negative ose me e madhe se 120 ");
        }

        this.age = age;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        if (city == null || city.trim().isEmpty()) {
            throw new IllegalArgumentException("qyteti nuk mund jete zbrazet ");
        }
        this.city = city;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        if (gender == null || gender.trim().isEmpty()) {
            throw new IllegalArgumentException("Mosha nuk mund te jete zbrazet ");
        }
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        if (nationality == null || nationality.trim().isEmpty()) {
            throw new IllegalArgumentException("Nacionaliteti nuk mund te jete zbrazet ");
        }
        this.nationality = nationality;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", age=" + age +
                ", city='" + city + '\'' +
                ", gender='" + gender + '\'' +
                ", nationality='" + nationality + '\'' +
                '}';
    }
}

