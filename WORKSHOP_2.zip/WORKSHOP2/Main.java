package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Album album = new Album(1, 1, "Album Name", new Date(), "album_image.jpg");
        Artist artist = new Artist("John", "Doe", 30, "New York", "Male", "American", 1, "Stage Name", "Rock", "artist_image.jpg");
        Track track = new Track(1, 1, "Track Name", 180, "track_path.mp3");
        Playlist playlist = new Playlist(1, 1, "Playlist Name", "playlist_image.jpg");
        User user = null;
        try {
            user = new User("Alice", "Smith", 25, "London", "Female", "British", 1, "alice@example.com", "password123", new Date(), "profile_image.jpg");
        } catch (UserException e) {
            e.printStackTrace();
        }
        Follower follower = new Follower(1, 1);

        // Create repositories
        AlbumsRepository albumsRepository = new AlbumsRepositoryImpl();
        ArtistRepository artistRepository = new ArtistRepositoryImpl();
        TracksRepository tracksRepository = new TrackRepositoryImpl();
        PlaylistRepository playlistRepository = new PlaylistRepositoryImpl();
        UserRepository userRepository = new UserRepositoryImpl();
        FollowersRepository followersRepository = new FollowersRepositoryImpl();

        // Add objects to repositories
        albumsRepository.add(album);
        artistRepository.add(artist);
        tracksRepository.add(track);
        playlistRepository.add(playlist);
        if (user != null) {
            userRepository.add(user);
        }
        followersRepository.add(follower);

        // Retrieve and display objects from repositories
        System.out.println("Albums:");
        for (Album a : albumsRepository.findAll()) {
            System.out.println(a);
        }

        System.out.println("\nArtists:");
        for (Artist a : artistRepository.findAll()) {
            System.out.println(a);
        }

        System.out.println("\nTracks:");
        for (Track t : tracksRepository.findAll()) {
            System.out.println(t);
        }

        System.out.println("\nPlaylists:");
        for (Playlist p : playlistRepository.findAll()) {
            System.out.println(p);
        }

        System.out.println("\nUsers:");
        for (User u : userRepository.findAll()) {
            System.out.println(u);
        }

        System.out.println("\nFollowers:");
        for (Follower f : followersRepository.findAll()) {
            System.out.println(f);
        }

        // Display Spotify-like menu
        spotifyMenu(tracksRepository);
    }

    private static void spotifyMenu(TracksRepository tracksRepository) {
        Scanner scanner = new Scanner(System.in);

        // Display Spotify-like menu
        System.out.println("\n\nSpotify-like Music Player:");
        System.out.println("1. Play a track");
        System.out.println("2. Pause");
        System.out.println("3. Resume");
        System.out.println("4. Stop");
        System.out.println("5. Next track");
        System.out.println("6. Previous track");
        System.out.println("7. Exit");

        boolean running = true;
        while (running) {
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Available tracks:");
                    List<Track> tracks = tracksRepository.findAll();
                    for (int i = 0; i < tracks.size(); i++) {
                        System.out.println((i + 1) + ". " + tracks.get(i).getName());
                    }
                    System.out.print("Enter the number of the track you want to play: ");
                    int trackNumber = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    if (trackNumber > 0 && trackNumber <= tracks.size()) {
                        Track selectedTrack = tracks.get(trackNumber - 1);
                        System.out.println("You are playing track: " + selectedTrack.getName());
                    } else {
                        System.out.println("Invalid track number.");
                    }
                    break;
                case 2:
                    System.out.println("Pausing...");
                    // Add your logic for pausing here
                    break;
                case 3:
                    System.out.println("Resuming...");
                    // Add your logic for resuming here
                    break;
                case 4:
                    System.out.println("Stopping...");
                    // Add your logic for stopping here
                    break;
                case 5:
                    System.out.println("Skipping to the next track...");
                    // Add your logic for skipping to the next track here
                    break;
                case 6:
                    System.out.println("Skipping to the previous track...");
                    // Add your logic for skipping to the previous track here
                    break;
                case 7:
                    System.out.println("Exiting...");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 7.");
            }
        }

        scanner.close();
    }
}
