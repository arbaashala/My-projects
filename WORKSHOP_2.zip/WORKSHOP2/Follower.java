package oop.intro_to_classes_and_objects.WORKSHOP2;

public class Follower {
    private int userId;
    private int artistId;

    public Follower(int userId, int artistId) {
        this.userId = userId;
        this.artistId = artistId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        if (userId <= 0 ) {
            throw new IllegalArgumentException("ID e userit nuk mund te jete negative");
        }
        this.userId = userId;
    }

    public int getArtistId() {
        return artistId;
    }

    public void setArtistId(int artistId) {
       if (artistId <= 0 ) {
           throw new IllegalArgumentException("ID e userit nuk mund te jete negative");
       }
        this.artistId = artistId;
    }

    @Override
    public String toString() {
        return "Follower{" +
                "userId=" + userId +
                ", artistId=" + artistId +
                '}';
    }
}
