package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.ArrayList;
import java.util.List;

public class FollowersRepositoryImpl implements FollowersRepository {
    private List<Follower> followers = new ArrayList<>();

    @Override
    public void add(Follower follower) {
        followers.add(follower);
    }

    @Override
    public Follower get(int id) {
        return followers.get(id);
    }

    @Override
    public void remove(int id) {
        followers.remove(id);
    }

    @Override
    public List<Follower> findAll() {
        return new ArrayList<>(followers);
    }
}
