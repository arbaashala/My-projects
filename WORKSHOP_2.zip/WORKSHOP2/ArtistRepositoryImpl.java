package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.ArrayList;
import java.util.List;

public class ArtistRepositoryImpl implements ArtistRepository {
    private List<Artist> artists;

    public ArtistRepositoryImpl() {
        this.artists = new ArrayList<>();
    }

    @Override
    public void add(Artist artist) {

        artists.add(artist);
    }

    @Override
    public Artist get(int id) {
       return artists.get(id);
    }

    @Override
    public void remove(int id) {
        artists.removeIf(album -> album.getArtistId() == id);
    }

    @Override
    public List<Artist> findAll() {
        return new ArrayList<>(artists);
    }
}
