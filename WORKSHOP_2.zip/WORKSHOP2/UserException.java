package oop.intro_to_classes_and_objects.WORKSHOP2;

public class UserException extends Exception {
    public UserException(String message) {
        super(message);

    }
    public UserException(String message, Throwable cause) {
        super(message, cause);
    }

    public UserException(){}

}
