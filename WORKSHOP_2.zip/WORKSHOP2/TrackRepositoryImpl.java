package oop.intro_to_classes_and_objects.WORKSHOP2;

import java.util.ArrayList;
import java.util.List;

public class TrackRepositoryImpl implements TracksRepository {
    private List<Track> tracks = new ArrayList<>();

    @Override
    public void add(Track track) {
        tracks.add(track);
    }

    @Override
    public Track get(int trackId) {
        return tracks.get(trackId);
    }

    @Override
    public void remove(int trackId) {
        tracks.remove(trackId);
    }

    @Override
    public List<Track> findAll() {
        return new ArrayList<>(tracks);
    }
}
