package oop.intro_to_classes_and_objects.WORKSHOP2;

public class Playlist {
    private int playlistId;
    private int userId;
    private String name;
    private String image;

    public Playlist(int playlistId, int userId, String name, String image) {
        this.playlistId = playlistId;
        this.userId = userId;
        this.name = name;
        this.image = image;
    }

    public int getPlaylistId() {
        return playlistId;
    }

    public void setPlaylistId(int playlistId) {
        if (playlistId < 0) {
            throw new IllegalArgumentException("ID e playlistit nuk mund te jete negative");
        }
        this.playlistId = playlistId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        if (userId < 0) {
            throw new IllegalArgumentException("ID e userit nuk mund te jete negative");
        }
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Emri nuk mund te jete i zbrazet");
        }
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        if (image == null || image.isEmpty()) {
            throw new IllegalArgumentException("Foto nuk mund te jete e zbrazet");
        }
        this.image = image;
    }

    @Override
    public String toString() {
        return "Playlist{" +
                "playlistId=" + playlistId +
                ", userId=" + userId +
                ", name='" + name + '\'' +
                ", image='" + image + '\'' +
                '}';
    }
}

